package com.tecsup.aopserva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopServaApplicationTests {

    @Test
    void contextLoads() {
    }

}
