package com.tecsup.aopserva.domain.persistence;

public interface AlumnoDao {
}
