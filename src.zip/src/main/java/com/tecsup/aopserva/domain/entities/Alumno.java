package com.tecsup.aopserva.domain.entities;

public class Alumno {
}
