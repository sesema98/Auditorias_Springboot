package com.tecsup.aopserva.handlers;

public class LoginSuccesHandler {
}
