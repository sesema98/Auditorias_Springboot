package com.tecsup.aopserva;

public class MvcConfig {
}
