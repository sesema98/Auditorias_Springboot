INSERT INTO cursos (nombre, creditos) VALUES ('Programmer', 5);
INSERT INTO cursos (nombre, creditos) VALUES ('Developer', 5);
INSERT INTO cursos (nombre, creditos) VALUES ('Expert', 5);
